<?php

namespace OncoAmazonPay\Exceptions;

use Exception;

class InvalidKeyException extends Exception
{
}
