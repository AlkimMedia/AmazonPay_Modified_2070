<?php

namespace OncoAmazonPay\Exceptions;

use Exception;

class ConfigException extends Exception
{
}
