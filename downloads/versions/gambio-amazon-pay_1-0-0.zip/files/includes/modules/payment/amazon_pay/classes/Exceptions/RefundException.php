<?php

namespace OncoAmazonPay\Exceptions;

use Exception;

class RefundException extends Exception
{
}
