<?php

namespace OncoAmazonPay\Exceptions;

use Exception;

class CaptureException extends Exception
{
}
