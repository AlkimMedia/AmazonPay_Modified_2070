<?php

namespace OncoAmazonPay\Exceptions;

use Exception;

class InvalidSessionIdException extends Exception
{
}
