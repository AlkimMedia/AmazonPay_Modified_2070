<?php
declare(strict_types=1);

class AmazonPayCronjobDependencies extends AbstractCronjobDependencies
{
    /**
     * @return array
     */
    public function getDependencies()
    {
        return [];
    }
}
