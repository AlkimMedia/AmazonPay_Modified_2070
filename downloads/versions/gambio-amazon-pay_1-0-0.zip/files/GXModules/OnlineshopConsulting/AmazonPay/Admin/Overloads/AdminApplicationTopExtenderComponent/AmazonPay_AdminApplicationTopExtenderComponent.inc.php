<?php

require_once DIR_FS_CATALOG . 'includes/modules/payment/amazon_pay/amazon_pay.inc.php';
class AmazonPay_AdminApplicationTopExtenderComponent extends AmazonPay_AdminApplicationTopExtenderComponent_parent{

}