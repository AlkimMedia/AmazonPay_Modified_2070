<?php

namespace OncoAmazonPay\Exceptions;

use Exception;

class AddressRestrictionException extends Exception
{
}
