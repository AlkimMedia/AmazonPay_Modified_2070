<?php

namespace OncoAmazonPay;

use Gambio\Core\Logging\LoggerBuilder;
use LegacyDependencyContainer;

class LogService
{
    const LOG_LEVEL_DEBUG = 'debug';
    const LOG_LEVEL_ERROR = 'error';
    protected static $logLevel = null;

    public function error($message, array $context = [])
    {
        $this->log(self::LOG_LEVEL_ERROR, $message, $context);
    }

    public function log($level, $message, array $context = [])
    {
        if (empty($this->logger)) {
            /** @var LoggerBuilder $loggerBuilder */
            $loggerBuilder = LegacyDependencyContainer::getInstance()->get(LoggerBuilder::class);
            $this->logger = $loggerBuilder->omitRequestData()->changeNamespace('amazon_pay')->build();
        }
        $this->logger->log($level, $message, $context);
    }

    public function debug($message, array $context = [])
    {
        if (self::$logLevel === null) {
            self::$logLevel = (new ConfigurationService())->getConfiguration()->getLogLevel();
        }
        if (self::$logLevel !== self::LOG_LEVEL_DEBUG) {
            return;
        }
        $this->log(self::LOG_LEVEL_DEBUG, $message, $context);
    }
}