<?php

namespace OncoAmazonPay\Exceptions;

use Exception;

class CountryException extends Exception
{
}
