<?php

require_once __DIR__.'/vendor/autoload.php';
$languageTextManager = MainFactory::create_object('LanguageTextManager', [], true);
$languageTextManager->init_from_lang_file('amazon_pay', $_SESSION['languages_id']);