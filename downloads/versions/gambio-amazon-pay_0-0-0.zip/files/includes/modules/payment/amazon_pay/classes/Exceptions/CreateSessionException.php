<?php

namespace OncoAmazonPay\Exceptions;

use Exception;

class CreateSessionException extends Exception
{
}
